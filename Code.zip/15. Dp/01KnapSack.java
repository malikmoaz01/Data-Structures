public class 01KnapScak {
    
}
